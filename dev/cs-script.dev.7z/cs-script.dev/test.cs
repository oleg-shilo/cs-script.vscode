//css_ref System.Windows.Forms
using System;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Forms;

class Script
{
    static void Main(string[] args)
    { 
         Console.WriteLine("Hello World!");
         MessageBox.Show("Hello World!");
    }
}